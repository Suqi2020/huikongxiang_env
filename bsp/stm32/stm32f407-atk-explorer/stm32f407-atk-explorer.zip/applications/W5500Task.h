#ifndef  __W5500TASK__
#define  __W5500TASK__

#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <string.h>





typedef enum
{
	 W5500InitEnum=0,
	 W5500DHCPEnum,
	 W5500NetOKEnum
}W5500_enum;










#endif


