#ifndef  __CRC_H__
#define  __CRC_H__
#include  "board.h"



uint16_t RTU_CRC(uint8_t *puchMsg , uint16_t usDataLen);





#endif

