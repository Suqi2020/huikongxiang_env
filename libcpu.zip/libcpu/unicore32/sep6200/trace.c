/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2017-07-17     Peng Fan     sep6200 implementation
 */
#include <rtthread.h>

void rt_hw_backtrace(rt_uint32_t *fp, rt_uint32_t thread_entry)
{

}
